<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Distancia entre Pontos</title>
</head>
<body>
    <?php 
    $pontoA = -8;
    $pontoB = 12;
    $distancia = 12 - (-8);
    echo "A distancia entre os pontos é: $distancia "; 
    abs($distancia);
    
    
    
    
    
    
    ?>
</body>
</html>