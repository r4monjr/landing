<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área do Trapezio</title>
</head>
<body>
    <?php 
    $baseMaior = 10;
    $baseMenor = 6;
    $altura = 4;
    $area = ($baseMaior + $baseMenor) * $altura;
    echo "A área do trapézio é: 32";

    ?>

</body>
</html>