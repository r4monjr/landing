<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Proposta 1 - Carrinho</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
function br_currency($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

$price = null;
$quantity = null;
$errors = [];
$subtotal = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $price = isset($_POST['price']) ? str_replace([',', ' '], ['.', ''], trim($_POST['price'])) : '';
    $quantity = isset($_POST['quantity']) ? trim($_POST['quantity']) : '';

    if ($price === '' || !is_numeric($price) || floatval($price) < 0) {
        $errors[] = 'Informe um preço válido (ex: 3500.00 ou 3.500,00).';
    }
    if ($quantity === '' || !ctype_digit($quantity) || intval($quantity) < 1) {
        $errors[] = 'Informe uma quantidade inteira positiva.';
    }

    if (empty($errors)) {
        $price = floatval($price);
        $quantity = intval($quantity);
        $subtotal = $price * $quantity;
    }
}
?>
<div class="panel">
  <h2>Proposta 1: Carrinho</h2>
  <form method="post">
    <label>Preço: <input type="text" name="price"></label><br><br>
    <label>Quantidade: <input type="number" name="quantity" min="1"></label><br><br>
    <button type="submit">Calcular</button>
  </form>

  <?php if($subtotal!==null): ?>
  <div class="output">
--- Orçamento PC-Pronto ---
Produto: <?= br_currency($price) ?> (x<?= $quantity ?>)
Subtotal: <?= br_currency($subtotal) ?>
  </div>
  <?php endif; ?>
</div>
</body>
</html>
