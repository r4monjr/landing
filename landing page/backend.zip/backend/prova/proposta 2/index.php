<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Proposta 2 - Imposto</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
function br_currency($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

$subtotal=$tax=$total_final=null;
$price=$quantity=null;$errors=[];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $price=str_replace([',',' '],['.',''],trim($_POST['price']??''));
    $quantity=trim($_POST['quantity']??'');
    if($price===''||!is_numeric($price)||$price<0){$errors[]='Preço inválido';}
    if($quantity===''||!ctype_digit($quantity)||$quantity<1){$errors[]='Quantidade inválida';}
    if(!$errors){
        $price=(float)$price;$quantity=(int)$quantity;
        $subtotal=$price*$quantity;
        $tax=$subtotal*0.125;
        $total_final=$subtotal+$tax;
    }
}
?>
<div class="panel">
  <h2>Proposta 2: Carrinho + Imposto</h2>
  <form method="post">
    <label>Preço: <input type="text" name="price"></label><br><br>
    <label>Quantidade: <input type="number" name="quantity" min="1"></label><br><br>
    <button type="submit">Calcular</button>
  </form>

  <?php if($subtotal!==null): ?>
  <div class="output">
--- Orçamento PC-Pronto ---
Produto: <?= br_currency($price) ?> (x<?= $quantity ?>)
Subtotal: <?= br_currency($subtotal) ?>
Imposto (12,5%): <?= br_currency($tax) ?>
Total Final: <?= br_currency($total_final) ?>
  </div>
  <?php endif; ?>
</div>
</body>
</html>
