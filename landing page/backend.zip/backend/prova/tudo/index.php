<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Orçamento PC-Pronto</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
function br_currency($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

$price=$quantity=null;
$errors=[];
$subtotal=$tax=$total_final=$frete=$total_com_frete=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
    $price=str_replace([',',' '],['.',''],trim($_POST['price']??''));
    $quantity=trim($_POST['quantity']??'');

    if($price===''||!is_numeric($price)||$price<0){$errors[]='Preço inválido';}
    if($quantity===''||!ctype_digit($quantity)||$quantity<1){$errors[]='Quantidade inválida';}

    if(!$errors){
        $price=(float)$price;
        $quantity=(int)$quantity;

        $subtotal=$price*$quantity;                 
        $tax=$subtotal*0.125;                       
        $total_final=$subtotal+$tax;                
        $frete=mt_rand(3000,15000)/100;            
        $total_com_frete=$total_final+$frete;      
    }
}
?>
<main>
  <h1>Orçamento PC-Pronto</h1>
  <section class="box">
    <form method="post">
      <p>
        <label for="price">Preço do produto:</label><br>
        <input type="text" name="price" id="price" value="<?=htmlspecialchars($_POST['price']??'')?>">
      </p>
      <p>
        <label for="quantity">Quantidade:</label><br>
        <input type="number" name="quantity" id="quantity" min="1" value="<?=htmlspecialchars($_POST['quantity']??'')?>">
      </p>
      <p>
        <input type="submit" value="Calcular">
      </p>
    </form>
  </section>

  <?php if($errors): ?>
    <section class="box error">
      <h2>⚠️ Erro</h2>
      <p><?= implode("<br>", $errors) ?></p>
    </section>
  <?php endif; ?>

  <?php if($subtotal!==null && !$errors): ?>
    <section class="box result">
      <h2>Proposta 1</h2>
      <p>Produto: <?= br_currency($price) ?> (x<?= $quantity ?>)</p>
      <p>Subtotal: <?= br_currency($subtotal) ?></p>
    </section>

    <section class="box result">
      <h2>Proposta 2</h2>
      <p>Subtotal: <?= br_currency($subtotal) ?></p>
      <p>Imposto (12,5%): <?= br_currency($tax) ?></p>
      <p><strong>Total Final: <?= br_currency($total_final) ?></strong></p>
    </section>

    <section class="box result">
      <h2>Proposta 3</h2>
      <p>Subtotal: <?= br_currency($subtotal) ?></p>
      <p>Imposto (12,5%): <?= br_currency($tax) ?></p>
      <p>Total Final: <?= br_currency($total_final) ?></p>
      <p>Frete: <?= br_currency($frete) ?></p>
      <p><strong>Valor Total com Frete: <?= br_currency($total_com_frete) ?></strong></p>
    </section>
  <?php endif; ?>
</main>
</body>
</html>
