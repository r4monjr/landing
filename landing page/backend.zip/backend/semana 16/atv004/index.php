<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Cartão de Visitas</title>
</head>
<body>
    <?php
$nome = 'Rafael';
$sobrenome = 'Secretário';
$cargo = 'Secretária';
echo "O profissional"  . $nome . $sobrenome . "trabalha no setor" . $cargo;

?>
</body>
</html>