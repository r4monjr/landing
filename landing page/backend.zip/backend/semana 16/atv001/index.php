<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu perfil</title>
</head>
<body>
    <?php
$meuNome = "Ramon";
$minhaIdade = 18;
print "Meu nome é $meuNome e eu tenho $minhaIdade. ";

     ?>

</body>
</html>