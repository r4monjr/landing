<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inspetor de Tipos</title>
</head>
<body>
    <?
$string = "PHP";
$integer = 2025;
$float = 9.5;
$bool = true;
var_dump($string, $integer, $float, $bool)
?>
</body>
</html>