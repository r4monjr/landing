<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Média</title>
</head>
<body>
   <?php
   $nota1 = 7.5;
   $nota2 = 8.0;
   $media = 7.75;
print "A média final é: $media"
   ?>
</body>
</html>